package JupiterToys.Automation;
import org.openqa.selenium.*;

public class AppDriver implements WebDriver{
	String AppURL;

}

