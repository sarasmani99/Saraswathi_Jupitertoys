package JupiterToys.Automation;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class GlobalMenuFragment extends Basepage{		
	
	public void ClickHomeMenu()
	{
		FindById("nav-home").click();
	}
	
	public void ClickShopMenu()
	{
		FindById("nav-shop").click();
	}
	
	public void ClickContactMenu()
	{
		FindById("nav-contact").click();
	}	
	
	public void ClickLogInLink()
	{
		WebElement element= FindById("nav-login");
		element.findElement(By.tagName("a")).click();
	}

}
