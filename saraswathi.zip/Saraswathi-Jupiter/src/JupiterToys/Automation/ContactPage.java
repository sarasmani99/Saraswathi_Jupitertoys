package JupiterToys.Automation;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

public class ContactPage extends Basepage{
	
	public void EnterForeName(String foreName)
	{
		FindById("forename").sendKeys(foreName);;
	}	
	public void EnterSurName(String surName)
	{
		FindById("surname").sendKeys(surName);;
	}	
	public void EnterEmail(String email)
	{
		FindById("email").sendKeys(email);;
	}	
	public void EnterTelePhone(String telePhone)
	{
		FindById("telephone").sendKeys(telePhone);;
	}	
	public void EnterMessage(String message)
	{
		FindById("message").sendKeys(message);;
	}	
	
	public void ClickSubmit()
	{
		WebElement element=FindElementByClassName("form-actions");
		element.findElement(By.linkText("Submit")).click();
	}

}
