package JupiterToys.Automation;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Basepage {
	protected ChromeDriver driver;
	public WebElement FindById(String id) 
	{
		return driver.findElement(By.id(id));
	}
	
	public WebElement FindByName(String name) 
	{
		return driver.findElement(By.name(name));
	}
	public WebElement FindElementByClassName(String className) 
	{
		return driver.findElement(By.className(className));
	}	
}
